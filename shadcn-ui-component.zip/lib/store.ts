import { create } from "zustand"

interface Video {
  id: string
  title: string
}

interface KaraokeStore {
  videos: Video[]
  currentVideo: Video | null
  queue: Video[]
  setVideos: (videos: Video[]) => void
  addVideos: (videos: Video[]) => void
  setCurrentVideo: (video: Video) => void
  addToQueue: (video: Video) => void
  removeFromQueue: (videoId: string) => void
  playNextInQueue: () => void
}

export const useKaraokeStore = create<KaraokeStore>((set) => ({
  videos: [],
  currentVideo: null,
  queue: [],
  setVideos: (videos) => set({ videos }),
  addVideos: (newVideos) => set((state) => ({ videos: [...state.videos, ...newVideos] })),
  setCurrentVideo: (video) => set({ currentVideo: video }),
  addToQueue: (video) =>
    set((state) => {
      // Prevent duplicates in queue
      if (state.queue.some((v) => v.id === video.id)) {
        return state
      }
      return { queue: [...state.queue, video] }
    }),
  removeFromQueue: (videoId) => set((state) => ({ queue: state.queue.filter((v) => v.id !== videoId) })),
  playNextInQueue: () =>
    set((state) => {
      if (state.queue.length === 0) return state
      const [nextVideo, ...remainingQueue] = state.queue
      return { currentVideo: nextVideo, queue: remainingQueue }
    }),
}))
