"use client"

import { useState } from "react"
import { useKaraokeStore } from "@/lib/store"

export default function PlayerControls() {
  const { currentVideo, videos, setCurrentVideo, queue, playNextInQueue } = useKaraokeStore()
  const [isPlaying, setIsPlaying] = useState(false)

  const getCurrentIndex = () => {
    return videos.findIndex((v) => v.id === currentVideo?.id)
  }

  const playNext = () => {
    if (queue.length > 0) {
      playNextInQueue()
      return
    }

    const currentIndex = getCurrentIndex()
    if (currentIndex === -1) return

    const nextIndex = (currentIndex + 1) % videos.length
    setCurrentVideo(videos[nextIndex])
  }

  const playPrevious = () => {
    const currentIndex = getCurrentIndex()
    if (currentIndex === -1) return

    const prevIndex = (currentIndex - 1 + videos.length) % videos.length
    setCurrentVideo(videos[prevIndex])
  }

  const handlePlayPause = () => {
    const player = (window as any).ytPlayer
    if (!player) return

    if (isPlaying) {
      player.pauseVideo()
    } else {
      player.playVideo()
    }
    setIsPlaying(!isPlaying)
  }

  return (
    <div className="flex gap-2 justify-center">
      <button
        onClick={playPrevious}
        className="p-2.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground transition-colors"
        title="Previous track"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M6 6h2v12H6zm3.5 6l8.5 6V6z" />
        </svg>
      </button>

      <button
        onClick={handlePlayPause}
        className="p-2.5 rounded-lg bg-primary hover:bg-primary/90 text-primary-foreground transition-colors"
        title="Play/Pause"
      >
        {isPlaying ? (
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
          </svg>
        ) : (
          <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z" />
          </svg>
        )}
      </button>

      <button
        onClick={playNext}
        className="p-2.5 rounded-lg bg-muted hover:bg-muted/80 text-foreground transition-colors"
        title="Next track"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M16 18h2V6h-2zm-11-7l8.5-6v12z" />
        </svg>
      </button>
    </div>
  )
}
