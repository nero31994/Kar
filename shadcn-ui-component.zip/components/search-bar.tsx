"use client"

import { useState } from "react"
import { useKaraokeStore } from "@/lib/store"

const SERVERS = [
  "https://ytapi3.kkt01.workers.dev",
  "https://ytapi2.nero-478.workers.dev",
  "https://ytapi.kkt01.workers.dev",
]

export default function SearchBar() {
  const [query, setQuery] = useState("")
  const [loading, setLoading] = useState(false)
  const { setVideos } = useKaraokeStore()
  let searchTimeout: NodeJS.Timeout

  const fetchVideos = async (searchQuery: string) => {
    setLoading(true)
    let attempts = 0

    while (attempts < SERVERS.length) {
      try {
        const url = `${SERVERS[attempts]}?q=${encodeURIComponent(searchQuery + " karaoke")}&t=${Date.now()}`
        const res = await fetch(url, { cache: "no-store" })
        const data = await res.json()

        setVideos(data.results || [])
        setLoading(false)
        return
      } catch (e) {
        attempts++
      }
    }

    setLoading(false)
  }

  const handleChange = (value: string) => {
    setQuery(value)

    clearTimeout(searchTimeout)

    if (value.trim().length === 0) {
      fetchVideos("karaoke")
      return
    }

    searchTimeout = setTimeout(() => {
      fetchVideos(value)
    }, 400)
  }

  return (
    <div className="relative max-w-2xl mx-auto">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => handleChange(e.target.value)}
          placeholder="Search karaoke songs..."
          className="w-full px-6 py-4 rounded-full border-2 border-border bg-card text-foreground placeholder-muted-foreground focus:outline-none focus:border-primary transition-colors"
        />
        <svg
          className="absolute right-6 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
          />
        </svg>
      </div>
      {loading && (
        <div className="absolute right-4 top-1/2 -translate-y-1/2">
          <div className="animate-spin">
            <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
            </svg>
          </div>
        </div>
      )}
    </div>
  )
}
