"use client"

import { useState } from "react"
import { useKaraokeStore } from "@/lib/store"
import { Play, ListPlus, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

export default function RecommendedSidebar() {
  const { videos, currentVideo, setCurrentVideo, queue, addToQueue, removeFromQueue } = useKaraokeStore()
  const [activeTab, setActiveTab] = useState<"recommended" | "queue">("recommended")

  // Filter out current video from recommendations
  const recommendations = videos.filter((v) => v.id !== currentVideo?.id)

  return (
    <div className="sticky top-24 bg-card border border-border rounded-xl overflow-hidden">
      {/* Tabs */}
      <div className="flex border-b border-border">
        <button
          onClick={() => setActiveTab("recommended")}
          className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${
            activeTab === "recommended"
              ? "bg-primary text-primary-foreground"
              : "bg-card text-muted-foreground hover:text-foreground"
          }`}
        >
          Recommended
        </button>
        <button
          onClick={() => setActiveTab("queue")}
          className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors relative ${
            activeTab === "queue"
              ? "bg-primary text-primary-foreground"
              : "bg-card text-muted-foreground hover:text-foreground"
          }`}
        >
          Queue
          {queue.length > 0 && (
            <span className="absolute top-2 right-2 bg-accent text-accent-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center">
              {queue.length}
            </span>
          )}
        </button>
      </div>

      {/* Content */}
      <ScrollArea className="h-[calc(100vh-200px)]">
        {activeTab === "recommended" && (
          <div className="p-2">
            {recommendations.length === 0 && (
              <div className="p-8 text-center text-muted-foreground text-sm">
                No recommendations yet. Search for songs to get started!
              </div>
            )}
            {recommendations.map((video) => (
              <div
                key={video.id}
                className="flex gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors group cursor-pointer"
              >
                <div
                  className="relative flex-shrink-0 w-32 h-20 bg-muted rounded-md overflow-hidden cursor-pointer"
                  onClick={() => setCurrentVideo(video)}
                >
                  <img
                    src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-8 h-8 text-white fill-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground line-clamp-2 mb-2">{video.title}</h4>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation()
                      addToQueue(video)
                    }}
                    className="h-7 px-2 text-xs"
                  >
                    <ListPlus className="w-4 h-4 mr-1" />
                    Reserve
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === "queue" && (
          <div className="p-2">
            {queue.length === 0 && (
              <div className="p-8 text-center text-muted-foreground text-sm">
                No songs in queue. Reserve songs from recommendations!
              </div>
            )}
            {queue.map((video, index) => (
              <div
                key={`${video.id}-${index}`}
                className="flex gap-3 p-2 rounded-lg hover:bg-accent/50 transition-colors group"
              >
                <div className="flex items-center justify-center w-6 text-sm font-bold text-muted-foreground">
                  {index + 1}
                </div>
                <div
                  className="relative flex-shrink-0 w-32 h-20 bg-muted rounded-md overflow-hidden cursor-pointer"
                  onClick={() => setCurrentVideo(video)}
                >
                  <img
                    src={`https://img.youtube.com/vi/${video.id}/mqdefault.jpg`}
                    alt={video.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-8 h-8 text-white fill-white" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-medium text-foreground line-clamp-2 mb-2">{video.title}</h4>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation()
                      removeFromQueue(video.id)
                    }}
                    className="h-7 px-2 text-xs text-destructive hover:text-destructive"
                  >
                    <X className="w-4 h-4 mr-1" />
                    Remove
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </ScrollArea>
    </div>
  )
}
