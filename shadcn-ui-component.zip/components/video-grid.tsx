"use client"

import { useEffect, useState, useRef, useCallback } from "react"
import { useKaraokeStore } from "@/lib/store"
import VideoCard from "./video-card"

const SERVERS = [
  "https://ytapi3.kkt01.workers.dev",
  "https://ytapi2.nero-478.workers.dev",
  "https://ytapi.kkt01.workers.dev",
]

const CACHE_KEY = "karaoke_cache"
const CACHE_TIME = 1000 * 60 * 60 * 6 // 6 hours
const BATCH_SIZE = 12

export default function VideoGrid() {
  const { setVideos, addVideos, videos } = useKaraokeStore()
  const [loading, setLoading] = useState(false)
  const [displayedCount, setDisplayedCount] = useState(BATCH_SIZE)
  const [nextContinuation, setNextContinuation] = useState<string | null>(null)
  const serverIndexRef = useRef(0)

  const getNextServer = useCallback(() => {
    serverIndexRef.current = (serverIndexRef.current + 1) % SERVERS.length
    return SERVERS[serverIndexRef.current]
  }, [])

  const saveCache = (query: string, results: any[], continuation?: string | null) => {
    const payload = {
      query,
      timestamp: Date.now(),
      results,
      continuation: continuation || null,
    }
    localStorage.setItem(CACHE_KEY, JSON.stringify(payload))
  }

  const loadCache = (query: string) => {
    const raw = localStorage.getItem(CACHE_KEY)
    if (!raw) return null

    try {
      const cache = JSON.parse(raw)
      if (Date.now() - cache.timestamp > CACHE_TIME) return null
      if (cache.query !== query) return null

      setNextContinuation(cache.continuation || null)
      return cache.results
    } catch {
      return null
    }
  }

  const fetchVideos = async (query: string, continuation?: string | null) => {
    let attempts = 0

    while (attempts < SERVERS.length) {
      const workerURL = getNextServer()
      try {
        let url = `${workerURL}?q=${encodeURIComponent(query)}&t=${Date.now()}`
        if (continuation) url += `&continuation=${continuation}`

        const res = await fetch(url, { cache: "no-store" })
        const data = await res.json()

        setNextContinuation(data.nextContinuation || null)
        saveCache(query, data.results, data.nextContinuation)

        return data.results || []
      } catch (e) {
        console.warn(`[v0] Server failed: ${workerURL}`, e)
        attempts++
      }
    }

    return []
  }

  const loadInitialVideos = async () => {
    setLoading(true)
    const cached = loadCache("karaoke")

    if (cached) {
      setVideos(cached)
      setDisplayedCount(BATCH_SIZE)
    } else {
      const fresh = await fetchVideos("karaoke")
      setVideos(fresh)
      setDisplayedCount(BATCH_SIZE)
    }

    setLoading(false)
  }

  const loadMore = async () => {
    if (displayedCount >= videos.length && nextContinuation) {
      setLoading(true)
      const newVideos = await fetchVideos("karaoke", nextContinuation)
      addVideos(newVideos)
      setLoading(false)
    }
    setDisplayedCount((prev) => prev + BATCH_SIZE)
  }

  useEffect(() => {
    loadInitialVideos()
  }, [])

  const displayedVideos = videos.slice(0, displayedCount)

  return (
    <div className="space-y-8">
      {/* Video Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {loading && displayedVideos.length === 0 ? (
          // Loading skeletons
          Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="aspect-video bg-muted rounded-lg animate-pulse" />
          ))
        ) : displayedVideos.length === 0 ? (
          <div className="col-span-full text-center py-12">
            <p className="text-muted-foreground">No karaoke tracks found</p>
          </div>
        ) : (
          displayedVideos.map((video) => <VideoCard key={video.id} video={video} />)
        )}
      </div>

      {/* Load More Button */}
      {displayedCount < videos.length || nextContinuation ? (
        <div className="flex justify-center pt-8">
          <button
            onClick={loadMore}
            disabled={loading}
            className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-semibold hover:bg-primary/90 disabled:opacity-50 transition-all"
          >
            {loading ? "Loading..." : "Load More"}
          </button>
        </div>
      ) : null}
    </div>
  )
}
