"use client"

import { useEffect } from "react"
import { useKaraokeStore } from "@/lib/store"
import PlayerControls from "./player-controls"

export default function KaraokePlayer() {
  const { currentVideo } = useKaraokeStore()

  useEffect(() => {
    // Initialize YouTube player
    if (typeof window !== "undefined" && (window as any).YT) {
      const playerDiv = document.getElementById("youtube-player")
      if (playerDiv && !playerDiv.querySelector("iframe")) {
        ;new (window as any).YT.Player("youtube-player", {
          height: "100%",
          width: "100%",
          videoId: currentVideo?.id || "",
          events: {
            onReady: (event: any) => {
              console.log("[v0] Player ready")
            },
          },
        })
      }
    }
  }, [currentVideo?.id])

  return (
    <div className="space-y-4">
      {/* Player */}
      <div className="bg-card rounded-xl overflow-hidden border border-border shadow-lg">
        <div id="youtube-player" className="w-full aspect-video bg-black" />
      </div>

      {/* Now Playing Info */}
      {currentVideo && (
        <div className="bg-card border border-border rounded-xl p-6">
          <h3 className="text-xl font-bold text-foreground mb-4">{currentVideo.title}</h3>
          <PlayerControls />
        </div>
      )}

      {!currentVideo && (
        <div className="bg-card border border-border rounded-xl p-12 text-center">
          <p className="text-muted-foreground">Select a track to start singing</p>
        </div>
      )}
    </div>
  )
}
