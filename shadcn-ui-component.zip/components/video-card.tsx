"use client"

import { useKaraokeStore } from "@/lib/store"
import Image from "next/image"
import { ListPlus } from "lucide-react"

interface VideoCardProps {
  video: {
    id: string
    title: string
  }
}

export default function VideoCard({ video }: VideoCardProps) {
  const { setCurrentVideo, addToQueue } = useKaraokeStore()
  const thumbnail = `https://i.ytimg.com/vi/${video.id}/mqdefault.jpg`

  return (
    <div className="group relative overflow-hidden rounded-lg border border-border hover:border-primary transition-all duration-300 hover:shadow-lg hover:shadow-primary/20">
      {/* Thumbnail */}
      <div
        className="relative aspect-video overflow-hidden bg-black cursor-pointer"
        onClick={() => setCurrentVideo(video)}
      >
        <Image
          src={thumbnail || "/placeholder.svg"}
          alt={video.title}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          onError={(e) => {
            e.currentTarget.src = "/karaoke-night.png"
          }}
        />
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
      </div>

      {/* Title */}
      <div className="absolute bottom-0 left-0 right-0 p-3 translate-y-2 group-hover:translate-y-0 transition-transform">
        <p className="text-xs font-bold text-white line-clamp-2 leading-tight">{video.title}</p>
      </div>

      {/* Play Icon */}
      <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        <div className="w-12 h-12 rounded-full bg-primary/90 flex items-center justify-center">
          <svg className="w-5 h-5 text-primary-foreground ml-0.5" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z" />
          </svg>
        </div>
      </div>

      <button
        onClick={(e) => {
          e.stopPropagation()
          addToQueue(video)
        }}
        className="absolute top-2 right-2 p-2 rounded-full bg-black/60 hover:bg-primary transition-colors opacity-0 group-hover:opacity-100 z-10"
        title="Reserve song"
      >
        <ListPlus className="w-4 h-4 text-white" />
      </button>
    </div>
  )
}
