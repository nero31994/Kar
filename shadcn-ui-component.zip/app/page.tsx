"use client"

import { useEffect, useState } from "react"
import KaraokePlayer from "@/components/karaoke-player"
import VideoGrid from "@/components/video-grid"
import SearchBar from "@/components/search-bar"
import RecommendedSidebar from "@/components/recommended-sidebar"

export default function Home() {
  const [isLoaded, setIsLoaded] = useState(false)

  useEffect(() => {
    // Load YouTube API
    const script = document.createElement("script")
    script.src = "https://www.youtube.com/iframe_api"
    script.async = true
    document.body.appendChild(script)
    setIsLoaded(true)
  }, [])

  return (
    <main className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="max-w-[1920px] mx-auto px-4 py-3 flex items-center gap-4">
          <h1 className="text-2xl font-bold">
            <span className="bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent">
              KARAOKE
            </span>
          </h1>
          <div className="flex-1 max-w-2xl">
            <SearchBar />
          </div>
        </div>
      </div>

      <div className="max-w-[1920px] mx-auto px-4 py-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Left: Player Section */}
          <div className="flex-1 lg:max-w-[70%]">
            <KaraokePlayer />
            {/* Video Grid below player */}
            <div className="mt-8">
              <h2 className="text-xl font-bold text-foreground mb-4">Browse Tracks</h2>
              <VideoGrid />
            </div>
          </div>

          {/* Right: Recommended & Queue Sidebar */}
          <div className="lg:w-[400px] xl:w-[450px]">
            <RecommendedSidebar />
          </div>
        </div>
      </div>
    </main>
  )
}
